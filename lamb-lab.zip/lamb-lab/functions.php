<?php
function lamb_lab_theme_setup() {
  register_nav_menus(array(
    'main-menu' => __( 'Main Menu', 'lamb-lab' )
  ));
}
add_action( 'after_setup_theme', 'lamb_lab_theme_setup' );
?>