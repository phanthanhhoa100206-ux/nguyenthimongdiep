<?php get_header(); ?>
<div class="container">
  <h1>Welcome to the Laboratory of Applied Microbiology and Biotechnology (LAMB)</h1>
  <p>Our research focuses on beneficial microorganisms and biotechnology to improve health, environment, and agriculture.</p>
  <h2>Latest News</h2>
  <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
    <div class="post">
      <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
      <div><?php the_excerpt(); ?></div>
    </div>
  <?php endwhile; endif; ?>
</div>
<?php get_footer(); ?>