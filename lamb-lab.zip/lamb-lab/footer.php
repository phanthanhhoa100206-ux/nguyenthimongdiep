<footer>
  <p>&copy; <?php echo date("Y"); ?> Laboratory of Applied Microbiology and Biotechnology (LAMB). All rights reserved.</p>
</footer>
<?php wp_footer(); ?>
</body>
</html>